import React from "react";
import Zoom from '../../assets/img/Zoom.png'
import Phone from '../../assets/img/Phone.png'

const AdCard = ({connectViaPhone, callByZoom, zoomContact, callContact, company, logo}) => {
    return (
        <div style={{marginTop: '30px'}} className="card product-card" style={{width: '18rem'}}>
                <img className="card-img-top top-img" src={logo} alt="Card image cap"/>
                <div clclassNameass="card-body">
                        <h5 className="card-title">{company}</h5>
                        <p className="card-text"></p>
                        
                        <div className="row" style={{display: "flex", justifyContent: "space-evenly", alignItems: "flex-end"}}>
                            <div className="col-5">
                                <img className="col-12 img-btn" 
                                    src={Zoom} 
                                    onClick={() => callByZoom(zoomContact)}      
                                />
                                <div className="col-12">Zoom</div>
                            </div>

                            <div className="col-5">
                                <img className="col-12 img-btn" 
                                src={Phone} 
                                onClick={() => connectViaPhone(callContact)}
                            />
                                <div style={{textAlign:'center'}} className="col-12">Call</div>
                            </div>    
                            
                        </div>
                </div>
        </div>
       
    )
}

export default AdCard;