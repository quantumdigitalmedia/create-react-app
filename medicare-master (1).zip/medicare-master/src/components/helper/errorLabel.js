import React from "react";

const ErrorLabel = ({text, color, fontSize, show}) => {
    return (
        <div style={{textAlign:"center"}} className="col-12">
            {show && <div style={{color, fontSize}}>
                {text}
            </div>}
        </div>
       
    )
}

export default ErrorLabel;