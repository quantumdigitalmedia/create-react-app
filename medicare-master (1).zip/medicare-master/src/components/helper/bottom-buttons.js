import React, { useEffect } from "react";

const BottomButtons = ({stepIt,shouldHideNextButton, currentStep, submitType}) => {
    
    return (
        <div style={{textAlign:"center", 
                        display: "flex", 
                        justifyContent: "center"
                    }} 
              className="row col-12 mt-2">

           {currentStep > 0 && 
                <input type="button" 
                        onClick={() => stepIt(-1)}
                        className="btn btn-info col-md-3 col-5 mr-1"
                        value="Previous"
                />
                
            }


           {/* {currentStep < 5 && !shouldHideNextButton() && */}
               {!shouldHideNextButton() && submitType &&
                   <input className="btn btn-success col-md-3 col-5 ml-1" 
                      value="Next"
                      type="submit"
               />}

                {!shouldHideNextButton() && !submitType &&
                   <input className="btn btn-success col-md-3 col-5 ml-1" 
                      value="Next"
                      type="buttpn"
                      onClick={() => stepIt(1)}
               />}
            {/* } */}
        </div>
       
    )
}

export default BottomButtons;