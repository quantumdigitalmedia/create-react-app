import React, { useEffect, useState } from "react";
import * as $ from 'jquery';
import * as _ from 'underscore';
import BottomButtons from "../helper/bottom-buttons";
import { Switch } from 'antd';
import { CloseOutlined, CheckOutlined } from '@ant-design/icons';

function StepFour({state, 
                  setState,
                  medicareCheckBoxNum,
                  setMedicareCheckBoxNum,
                  stepIt,
                  currentStep }) {

        
        const selectCheckboxOption = (val) => {
            let clonedState = _.clone(state);
            clonedState[val] = clonedState[val] == 'n' ? 'y' : 'n';
            setState(clonedState);
        }

        const shouldHideNextButton = () => {
            return false;
        }

        useEffect(() => {
            console.log(state)
        }, [state])

        return (
            <div className="border-custom" 
            >
               <div className="top-section row">
                    <h2>What additional benefit you would like your plan to have? </h2>
               </div>

                <div className="checkbox-container">
                    <input type="checkbox" 
                            id="drug"
                            name="want"
                            checked={state.drug == 'y'}
                            onClick={() => selectCheckboxOption('drug')}
                    />
                    <label htmlFor="drug">Drug</label>

                    <input type="checkbox" 
                            id="vision"
                            name="want"
                            checked={state.vision == 'y'}
                            onClick={() => selectCheckboxOption('vision')}
                    />
                    <label htmlFor="vision">Vision</label>

                    <input type="checkbox" 
                            id="hearing"
                            name="want"
                            checked={state.hearing == 'y'}
                            onClick={() => selectCheckboxOption('hearing')}
                    />
                    <label htmlFor="hearing">Hearing</label>

                    <input type="checkbox" 
                            id="dental"
                            name="want"
                            checked={state.dental == 'y'}
                            onClick={() => selectCheckboxOption('dental')}
                    />
                    <label htmlFor="dental">Dental</label>

                   
                </div>

                <BottomButtons shouldHideNextButton={shouldHideNextButton}
                                    stepIt={stepIt}
                                    currentStep={currentStep}
                    />

               {/* <div className="details-section row">
                    <div className="col-md-12 f15">Why are you looking for Coverage?</div>
                    <div style={{paddingTop: 5}} className="col-md-12">
                        <div style={{position:"relative"}} className="radio-option-holder">
                            <input style={{position: "absolute", 
                                            left: "10px"}} 
                                    type='checkbox'
                                    name="want"
                                    checked={state.drug == 'y'}
                                    onChange={() => selectCheckboxOption('drug')}
                                    className="radio-rect"
                            />
                            <div className="radio-option radio-option-one">
                                Drug
                            </div>
                        </div>
                    </div>

                    <div style={{paddingTop: 5}} className="col-md-12">
                        <div style={{position:"relative"}} className="radio-option-holder">
                            <input style={{position: "absolute", 
                                            left: "10px"}} 
                                    type='checkbox'
                                    name="want"
                                    checked={state.vision == 'y'}
                                    onChange={() => selectCheckboxOption('vision')}
                                    className="radio-rect"
                            />
                            <div className="radio-option radio-option-two">
                                Vision
                            </div>
                        </div>
                    </div>

                    <div style={{paddingTop: 5}} className="col-md-12">
                        <div style={{position:"relative"}} className="radio-option-holder">
                            <input style={{position: "absolute", 
                                            left: "10px"}} 
                                    type='checkbox'
                                    name="want"
                                    checked={state.hearing == 'y'}
                                    onChange={() => selectCheckboxOption('hearing')}
                                    className="radio-rect"
                            />
                            <div className="radio-option radio-option-three">
                                Hearing
                            </div>
                        </div>
                    </div>

                    <div style={{paddingTop: 5}} className="col-md-12">
                        <div style={{position:"relative"}} className="radio-option-holder">
                            <input style={{position: "absolute", 
                                            left: "10px"}} 
                                    type='checkbox'
                                    name="want"
                                    checked={state.dental == 'y'}
                                    onChange={() => selectCheckboxOption('dental')}
                                    className="radio-rect"
                            />
                            <div className="radio-option radio-option-four">
                                Dental
                            </div>
                        </div>
                    </div>

                    <BottomButtons shouldHideNextButton={shouldHideNextButton}
                                    stepIt={stepIt}
                                    currentStep={currentStep}
                    />
                    </div> */}
               </div>

        );
}

export default StepFour;