import React, { useEffect, useRef, useState } from "react";
import * as $ from 'jquery';
import * as _ from 'underscore';
import { useForm } from "react-hook-form";
import ErrorLabel from "../helper/errorLabel";
import emailValidator from 'email-validator';
import BottomButtons from "../helper/bottom-buttons";

function StepThree({state, 
                  setState,
                  stepIt,
                  currentStep
                  
                   }) {
    
    const [tempState, setTempState] = useState(state);
    const btnSubmitRefs = useRef(null);
    const {register, handleSubmit, formState: {errors}} = useForm();
    const onSubmit  = (data) => {
        let stateClone = _.clone(state);
        stateClone.firstName = data.firstName;
        stateClone.lastName = data.lastName;
        stateClone.email = data.email;
        setState(stateClone);
        
        stepIt(1);
    }

    const  isvalidEmail = (val) => {
        return emailValidator.validate(val);
    }

    const onChangeInput = (propName, e) => {
        let stateClone = _.clone(state);
        stateClone[propName] = e.target.value;
        setState(stateClone);
        
    }

    const shouldHideNextButton = () => {
        return false;
        return state.lastName.trim().length == 0 ||  
                state.firstName.trim().length == 0  || 
                state.email.trim().length == 0
    }

    useEffect(() => {
        setTempState(state);
    },[state])




        return (
            <form onSubmit={handleSubmit(onSubmit)} className="border-custom" data-animation="slideHorz" >
               <div className="top-section row">
                    <h2>Who are we preparing this quote for? </h2>
               </div>

                <div className="row" style={{display:"flex", justifyContent: "center"}}>
                    <div className="floating-label col-md-7 col-sm-8 col-12">      
                            <input className="floating-input" 
                                    type="text" 
                                    placeholder=""
                                    name="firstName"
                                    {...register("firstName", {required:true})}
                                    onChange={(e) => onChangeInput("firstName", e)}
                                    value={state.firstName}
                            
                            /> 
                            <span className="highlight"></span>
                            <label>First Name</label>
                    </div>
                    {errors.firstName && 
                            <ErrorLabel show text="First Name is required" color="red" fontSize="20px" />
                    }
                    </div>
                    <br /><br />
                    <div className="row" style={{display:"flex", justifyContent: "center"}}>
                        <div className="floating-label col-md-7 col-sm-8 col-12">      
                                <input className="floating-input" 
                                        type="text" 
                                        placeholder=""
                                        name="lastName"
                                        {...register("lastName", {required:true})}
                                        onChange={(e) => onChangeInput("lastName", e)}
                                        value={state.lastName}
                                
                                /> 
                                <span className="highlight"></span>
                                <label>Last Name</label>
                        </div>
                        {errors.lastName && 
                                <ErrorLabel show text="Last Name is required" color="red" fontSize="20px" />
                        }
                    </div>
                    <br /><br />
                    <div className="row" style={{display:"flex", justifyContent: "center"}}>
                        <div className="floating-label col-md-7 col-sm-8 col-12">      
                                    <input className="floating-input" 
                                            type="text" 
                                            placeholder=""
                                            {...register("email", {required: true, validate:isvalidEmail})}
                                            name="email"
                                            onChange={(e) => onChangeInput("email",e)}
                                            value={state.email}
                                    
                                    /> 
                                    <span className="highlight"></span>
                                    <label>Email</label>
                        </div>
                            {errors.email && errors.email.type === 'required' && 
                            <ErrorLabel show text="Email is required" color="red" fontSize="20px" />
                            }
                            {errors.email && errors.email.type === 'validate' && 
                                <ErrorLabel show text="Please type a valid email" color="red" fontSize="20px" />
                            }
                    </div>

           
            <BottomButtons shouldHideNextButton={shouldHideNextButton}
                                    stepIt={stepIt}
                                    currentStep={currentStep}
                                    submitType
            />
            </form >

        );
}

export default StepThree;