import {Select} from 'antd'
import { DatePicker } from "antd";
import React, { useEffect, useState } from "react";
import * as _ from 'underscore';
import BottomButtons from '../helper/bottom-buttons';
import ErrorLabel from '../helper/errorLabel';

const {Option} = Select;

function StepTwo({state, 
                   setState,
                   isValidDob,
                  stepIt,
                  currentStep}) {

    const [numStateGender, setNumStateGender] = useState(0);
    const [clonedState2, setCloneState2] = useState({});
    const selectRadioOption = (num) => {
        let Gender = null;
        if(num == 'one') {
            setNumStateGender(1);
            Gender = "male";
        }
        if(num == 'two') {
            setNumStateGender(2);
            Gender = "female";
        }
        if(num == 'three') {
            setNumStateGender(3);
            Gender = "Do not wish to specify";
        }
       
        let clonedState = _.clone(state);
        clonedState.Gender = Gender;
        setState(clonedState);
        $('.radio-option').removeClass('selected-option');
        $('.radio-option-' + num).addClass('selected-option');
    }

    const handleMonthChange = (e) => {
        
        let clonedState = _.clone(state);
        clonedState.Month = e.target.value;
        setState(clonedState);
    }

    const handleGenderSelect = (e) => {
        let clonedState = _.clone(state);
        clonedState.Gender = e.target.value;
        setState(clonedState);
    }

    const onMouseUp = (propName, e) => {
        let clonedState = _.clone(state);
        clonedState[propName] = e.target.value;
        setState(clonedState);
    }

    const shouldHideNextButton = () => {
        return !isValidDob() || state.Gender == "";
    }

    useEffect(() => {
        let clonedState = _.clone(state);
        setCloneState2(clonedState);
    }, [state])
   
    return (
            <div className="border-custom" >
                <div className="top-section row">
                    <h2>What is your Gender </h2>
                </div>

                <div className="row col-md-12" 
                    style={{display:"flex", justifyContent: "center", height:"100px"}}>
                    

                    <div className="floating-label col-md-3 col-sm-4 col-12"> 
                        <select className="floating-select" 
                                defaultValue={state.Gender} 
                                onChange={handleGenderSelect}
                                value={state.Gender}
                        >
                            <option value=""></option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            <option value="not specified">Do not wish to specify</option>
                        </select> 
                        
                        <span className="highlight"></span>
                        <label>Gender</label>
                    </div> 
                </div>

            {/* <fieldset>
                <legend>Date of Birth</legend> */}
                <div className="top-section row">
                    <h2>When were you born? </h2>
                </div>

                <div className="row col-md-12 pl-1 pr-1" style={{display: "flex", justifyContent: "center"}}>
                    <div className="floating-label col-md-3 col-sm-3 col-5"> 
                            <select className="floating-select" 
                                    defaultValue={state.Month} 
                                    onChange={handleMonthChange}
                                    value={state.Month}
                            >
                                <option value="1">January</option>
                                <option value="2">February</option>
                                <option value="3">March</option>
                                <option value="4">April</option>
                                <option value="5">May</option>
                                <option value="6">June</option>
                                <option value="7">July</option>
                                <option value="8">August</option>
                                <option value="9">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select> 
                            
                            <span className="highlight"></span>
                            <label>Month</label> 
                        </div>
                {/* </fieldset> */}

                    

                        <div className="floating-label col-md-1 col-3">      
                            <input className="floating-input" 
                                    type="text" 
                                    placeholder=""
                                    value={state.Day}
                                    onChange={(e) => onMouseUp('Day', e)}
                            
                            /> 
                            <span className="highlight"></span>
                            <label>Day</label>
                        </div>

                        <div className="floating-label col-md-1 col-4">      
                            <input className="floating-input" 
                                    type="text" 
                                    placeholder=""
                                    value={state.Year}
                                    onChange={(e) => onMouseUp('Year', e)}
                            
                            /> 
                            <span className="highlight"></span>
                            <label>Year</label>
                        </div>

                        <ErrorLabel 
                            color="red"
                            text="A valid date info must be entered"
                            fontSize="1rem"
                            show={!isValidDob()}
                            />
                </div>

                <BottomButtons shouldHideNextButton={shouldHideNextButton}
                                        stepIt={stepIt}
                                        currentStep={currentStep}
                />
            </div >
        );
}

export default StepTwo;