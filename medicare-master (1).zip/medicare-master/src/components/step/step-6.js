import React, { useEffect, useRef, useState } from "react";
import * as _ from 'underscore';
import { useForm } from "react-hook-form";
import ErrorLabel from "../helper/errorLabel";
import BottomButtons from "../helper/bottom-buttons";
import 'react-phone-number-input/style.css'
import PhoneNumber from 'awesome-phonenumber';
import {Modal} from 'antd';
import {sendSms} from "../../../src/assets/js/axios-calls";

function StepSix({state, 
                  setState,
                  stepIt,
                  currentStep,
                  setCurrentStep,
                  setShowSpinner
                   }) {
    const [showModal, setShowModel] = useState(false);
    const [randomNumber, setRandomNumber] = useState(0);
    const [randomNumberInput, setRandomNumberInput] = useState(null);
    const btnSubmitRefs = useRef(null);
    const {register, handleSubmit, formState: {errors}} = useForm();
    const onSubmit  = (data) => {
        let stateClone = _.clone(state);
        stateClone.mobile = data.mobile;
        stateClone.mobileValid = true;
        stateClone.mobileVerified = false;
        setState(stateClone);
        sendVerificationCode(data.mobile);
        //stepIt(1);
    }

    const  isvalidPhone = (val) => {
        let pn = new PhoneNumber( val, 'us' );
        let stateClone = _.clone(state);
        stateClone.mobileValid = pn.isValid(); 
        stateClone.mobileVerified = false;
        stateClone.mobile = val;
        setState(stateClone);
        return pn.isValid();
    }

    const onChangeInput = (propName, e) => {
        let stateClone = _.clone(state);
        stateClone[propName] = e.target.value; 
        let pn = new PhoneNumber( e.target.value, 'us' );
        stateClone.mobileValid = pn.isValid(); 
        stateClone.mobileVerified = false;
        setState(stateClone);
        
    }

    const shouldHideNextButton = () => {
        return !state.mobileValid;
    }

    const sendVerificationCode = (num) => {
        let randomNum = Math.floor(100000 + Math.random() * 900000);
        if(!showModal)
            setShowSpinner(true);

        //return console.log(randomNum)
        sendSms(num, randomNum).then(res => {
            setRandomNumber(randomNum);
            if(!showModal)
                setShowModel(true);
            
            setShowSpinner(false);
            
        },err => {
            
        })
    }

    const onCheckedConsent = (e) => {
        
        let stateClone = _.clone(state);
        stateClone.consent = stateClone.consent == "n" ? "y" : "n";
        setState(stateClone);
    }

    const confirmVerifyCode = () => {
        let stateClone = _.clone(state);
        if(state.mobileVerified && state.consent == 'y') {
            stepIt(1);
        }
        else if(state.mobileVerified && state.consent != 'y') {
            alert("You must click the checkbox to agree");
        }
        else if(randomNumberInput == randomNumber) {
            stateClone.mobileVerified = true;
        }
        
        else {
            stateClone.mobileVerified = false; 
            alert("Wrong verification code entered");
        }    
        setState(stateClone);              
    }

    useEffect(() => {
        let stateClone = _.clone(state);
        stateClone.consent = "n";
        setState(state);
    },[])


    // useEffect(() => {
    //     if(showConsent) {
    //         let stateClone = _.clone(state);
    //         stateClone.consent = "y";
    //         setState(stateClone);               
    //         stepIt(1);
    //     }
    // },[showConsent])

    useEffect(() => {
        
        if(state.mobileVerified && state.consent == 'y') {
            //stepIt(1);
        }
    },[state])

    return (
            <form onSubmit={handleSubmit(onSubmit)} className="border-custom" data-animation="slideHorz" >
               <div className="top-section row">
                    <h2>The best number to reach you</h2>
               </div>
                <br />
             
               <div className="row" style={{display:"flex", justifyContent: "center"}}>
                    <div className="floating-label col-8">      
                                            <input className="floating-input" 
                                                   {...register("mobile", {required: true, validate:isvalidPhone})}
                                                   name="mobile"
                                                   onChange={(e) => onChangeInput("mobile",e)}
                                                   value={state.mobile}
                                            
                                            /> 
                                            <span className="highlight"></span>
                                            <label>Mobile</label>
                        {errors.mobile && errors.mobile.type === 'required' && 
                            <ErrorLabel show text="Mobile is required" color="red" fontSize="2vw" />
                        }
                        {errors.mobile && errors.mobile.type === 'validate' && 
                            <ErrorLabel show text="Please type a valid US Mobile" color="red" fontSize="2vw" />
                        }
                    </div>
               </div>
       
            <BottomButtons shouldHideNextButton={shouldHideNextButton}
                                    stepIt={stepIt}
                                    currentStep={currentStep}
                                    submitType
            />

            <Modal title="Mobile Verification"
                    visible={showModal}
                    onCancel={() => setShowModel(false)}
                    onOk={confirmVerifyCode}
                    okText={!state.mobileVerified ? "Verify" : "Show My Options"}
                    cancelText="Cancel"
                    className="verification-modal"
            >
               
                {!state.mobileVerified && 
                    <div >
                        <label>Please enter the verification code sent to your mobile via SMS</label>
                        <input type="text" 
                            style={{border: '1px #A9A9A9 solid',
                                    
                                }}
                            placeholder="Enter Code Here"
                            defaultValue={randomNumberInput}
                            value={randomNumberInput}
                            onChange={(e) => setRandomNumberInput(e.target.value)}
                        />
                        <div style={{width: '100%'}}>
                            <button style={{ border: 'none',
                                            color: 'blue',
                                            cursor: 'pointer',
                                            background:'none'
                                            }}
                                    onClick={() => sendVerificationCode(state.mobile)}
                            >
                                Resend Code
                            </button>
                        </div>
                    </div>
                }

                {state.mobileVerified && <div className="row col-12" 
                     style={{display: "flex", 
                             justifyContent: "left",
                             //alignItems: "center",
                             marginTop: "15px"
                            }}
                >
                    <div className="col-1">
                        <input type="checkbox"
                            className="scale-2"
                            checked={state.consent == 'y'} 
                            onClick={(e) => onCheckedConsent(e)}
                        />
                    </div>
                    
                    <div className="col-11">
                    I agree with the Terms and conditions and Privacy Policy. 
                    By clicking See My Options button you are agree with PolicyFetch Inc 
                    terms and conditions (Hyperlink to /terms-and-conditions) and 
                    Privacy Policy (Hyperlink to /privacy-policy) and authorize 
                    Policyfetch Inc, its carriers, and its network of Marketing 
                    partners and service providers to contact you at the 
                    phone number you entered using automated technology 
                    including auto-dialers, pre-recorded messages, and text messages, 
                    even if your phone number is a mobile number or is currently listed 
                    on any state, federal, or corporate “Do Not Call” lists, and you 
                    are not required to give your consent as a condition of service 
                    </div>
                    
                </div>}
               
               
            </Modal>
            </form >

        );
}

export default StepSix;