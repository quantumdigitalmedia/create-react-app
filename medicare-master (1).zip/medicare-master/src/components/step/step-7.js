import React, { useEffect } from 'react';
import Zoom from '../../assets/img/Zoom.png'
import Phone from '../../assets/img/Phone.png'
import { connectCall, 
        openZoomCall, 
        openNotificationWithIcon, 
        saveMedicareInfo 
        } 
from '../../assets/js/axios-calls';
import * as _ from 'underscore';
import AdCard from '../helper/ad-card';

const styles = {height: '10vh', 
display: "flex",
justifyContent: "center",
border: "1px solid grey",
padding: "15px"
}

function Step7 ({state, 
                        setState,
                        stepIt,
                        currentStep,
                        setCurrentStep,
                    showSpinner,
                setShowSpinner})
{

    const savedata = (obj) => {
        saveMedicareInfo(obj).then(response => {
            
        }, err => {

        })

      
    }

    const callByZoom = (vendor) => {
        let clonedState = _.clone(state);
        clonedState.CallNow = true;
        clonedState.ZoomNow = false;
        clonedState.CallBackLater = false;
        clonedState.vendor = vendor;
        openZoomCall().then(response => {
            //save data
            savedata(clonedState);
        }, err => {
            console.log("err", err)
        })
    }

    const connectViaPhone = (vendor) => {
        const message = "Please wait while we connect you to an agent.";
        let clonedState = _.clone(state);
        clonedState.CallNow = true;
        clonedState.ZoomNow = false;
        clonedState.CallBackLater = false;
        clonedState.vendor = vendor;
        connectCall(clonedState.mobile, vendor, message).then(res => {
                //save the data 
                savedata(clonedState);
        }, err => {
            let title = 'Error';
            let description = 'An error occured while connecting the call'
            openNotificationWithIcon('error', title, description);
        })
    }

    useEffect(() => {
        setShowSpinner(true);

        setTimeout(() => {
            setShowSpinner(false);
        }, 4000);
    }, [])

    return (
        <div style={{display: showSpinner ? 'none' : 'inline'}}>
             <div className="top-section row">
                    <h2>Product Menu Selections</h2>
               </div>
               <div className="products-container">
                    <div className="row"
                         style={{display: "flex",
                         justifyContent: "space-evenly"}}
                    >

                        <AdCard 
                            connectViaPhone={connectViaPhone}
                            callByZoom={callByZoom}
                            zoomContact="MedicareVendorZoom1"
                            callContact="MedicareVendorCall1"
                            company="Second Vendor"
                            logo="https://gw.alipayobjects.com/zos/rmsportal/JiqGstEfoWAOHiTxclqi.png"
                        />  

                        <AdCard 
                            connectViaPhone={connectViaPhone}
                            callByZoom={callByZoom}
                            zoomContact="MedicareVendorZoom2"
                            callContact="MedicareVendorCall2"
                            company="Second Vendor"
                            logo="https://gw.alipayobjects.com/zos/rmsportal/JiqGstEfoWAOHiTxclqi.png"
                        />  
                    </div>
               </div>      
        </div>
    )
}

export default Step7;