import React, { useEffect, useState } from "react";
import * as $ from 'jquery';
import * as _ from 'underscore';
import BottomButtons from "../helper/bottom-buttons";
import {Radio} from 'antd';
import { myPlansUrl } from "../../assets/js/constants";

const options = [
    { label: 'Enroll Medicare for the first time', value: 'one' },
    { label: 'Replace an original Medicare or Medigap plan', value: 'two' },
    { label: 'Replace a current Medicare advantage plan', value: 'three' },
    { label: 'Replace or Enroll in a Medicare Part D(Rx) plan', value: 'four' },
    { label: 'I am not sure. Help me choose an option.', value: 'five' }
  ];

  const radioStyle = {
    //fontSize: 'calc(0.5rem + 2vw)',
    height: 'calc(2rem + 2vw)',
    width: '100%',
    //lineHeight: '70px',
    display: 'flex',
    justifyContent:  'center',
    alignItems: 'center'
  };

function StepOne({state, 
                  setState,
                  medicareCheckBoxNum,
                  setMedicareCheckBoxNum ,
                 stepIt,
                currentStep}) {

        const [showMyPlans, setShowMyPlans] = useState(false);
    

        const shouldHideNextButton = () => {
            return false
        }
        const selectRadioOption = (e) => {
            let num = e.target.value
            
            let Step1_Medicare = null;
            if(num == 'one') {
                setMedicareCheckBoxNum(1);
                 Step1_Medicare = "Enroll Medicare for the first time";
                 
            }
            if(num == 'two') {
                setMedicareCheckBoxNum(2);
                 Step1_Medicare = "To replace an original Medicare or Medigap plan";
            }
            if(num == 'three') {
                setMedicareCheckBoxNum(3);
                 Step1_Medicare = "To replace a current Medicare advantage plan";
            }
            if(num == 'four') {
                setMedicareCheckBoxNum(4);
                 Step1_Medicare = "To Replace or Enroll in a Medicare Part D(Rx) plan";
            }
            if(num == 'five') {
                setMedicareCheckBoxNum(5);
                 Step1_Medicare = "I am not sure. Help me choose an option.";
            }
            let clonedState = _.clone(state);
            clonedState.Step1_Medicare = Step1_Medicare;
            clonedState.Step1_Medicare_Num = num;
            setState(clonedState);

            setShowMyPlans(clonedState.Step1_Medicare_Num == 'one' || clonedState.Step1_Medicare_Num == 'three');
            
        }

        useState(() => {
            setShowMyPlans(state.Step1_Medicare_Num == 'one' || state.Step1_Medicare_Num == 'three');
        }, [])

        return (
            <div className="border-custom" 
                 //data-animation="slideHorz" 
                 style={{marginTop: "10px"}}
            >
                
               <div className="top-section row">
                    <h2>In order to prepare your quote, 
                        we need a bit of information from you. 
                        What got you looking 
                        for Medicare options today? 
                    </h2>
                    {/* <div>Located in {state.city}, {state.state}</div>
                    <div>To prepare your quote, please provide us with more info</div> */}
               </div>

               <div className="row">
               {showMyPlans && <div className="col-12" style={{display:"flex", justifyContent: "center" , padding: '10px 0'}}>
                   <button onClick={() => {
                                window.open(myPlansUrl, '_blank');
                            }} 
                            className="btn btn-view-plan">
                        View My Plans
                    </button>
               </div>}
               <Radio.Group onChange={selectRadioOption} 
                       value={state.Step1_Medicare_Num}
                       //defaultValue={options[0].value}
                       optionType="button"
                       buttonStyle="solid"
                       className="col-md-7 col-sm-10 col-12"
                       >
                       
                       {
                           options.map((op, i) => {
                               return (
                                   <Radio.Button className='step-1-radio' style={radioStyle} value={op.value} key={i}>
                                       {op.label}
                                   </Radio.Button>
                               )
                           })
                       }

                </Radio.Group>
                   
                <BottomButtons shouldHideNextButton={shouldHideNextButton}
                                stepIt={stepIt}
                                currentStep={currentStep}
                />
               </div>
            </div >

        );
}

export default StepOne;