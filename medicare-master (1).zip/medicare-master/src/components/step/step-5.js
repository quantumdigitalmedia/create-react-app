import React, { useEffect, useRef } from "react";
import * as $ from 'jquery';
import * as _ from 'underscore';
import { useForm } from "react-hook-form";
import ErrorLabel from "../helper/errorLabel";
import emailValidator from 'email-validator';
import BottomButtons from "../helper/bottom-buttons";

function StepFive({state, 
                  setState,
                  stepIt,
                  currentStep
                  
                   }) {
    
    const btnSubmitRefs = useRef(null);
    const {register, handleSubmit, formState: {errors}} = useForm();
    const onSubmit  = (data) => {
        let stateClone = _.clone(state);
        stateClone.street = data.street;
        stateClone.street2 = data.street2;
        setState(stateClone);

        stepIt(1);
      
    }

    const onChangeInput = (propName, e) => {
        let stateClone = _.clone(state);
        stateClone[propName] = e.target.value;
        setState(stateClone);
        
    }

    const shouldHideNextButton = () => {
        return (state.zip && state.zip.trim() == "") || 
               (state.state &&  state.state.trim()) == "" || 
               (state.city && state.city.trim()) == "" || 
               (state.street && state.street.trim()) == "";
    }

        return (
            <form onSubmit={handleSubmit(onSubmit)} className="border-custom" data-animation="slideHorz" >
               <div className="top-section row">
                    <h2>Where do you live?</h2>
               </div>

               <div className="row" style={{display:"flex", justifyContent:"center"}}>
                    <div className="floating-label col-8">      
                                    <input className="floating-input" 
                                            
                                            {...register("street", {required:true})}
                                            name="street"
                                            onChange={(e) => onChangeInput("street",e)}
                                            value={state.street}
                                    
                                    /> 
                                    <span className="highlight"></span>
                                    <label>Street</label>
                    {errors.street && 
                        <ErrorLabel show text="Street is required" color="red" fontSize="20px" />
                    }
                    </div>
                    

                    <div className="floating-label col-4">      
                                    <input className="floating-input" 
                                            
                                            {...register("street2")}
                                            name="street2"
                                            onChange={(e) => onChangeInput("street2",e)}
                                            value={state.street2}
                                    
                                    /> 
                                    <span className="highlight"></span>
                                    <label>Street2</label>
                    </div>
                    <div className="col-12" style={{height: "50px"}}>

                    </div>
                    <div className="floating-label col-6">      
                                    <input className="floating-input" 
                                            
                                            {...register("city", {required: true})}
                                            name="city"
                                            onChange={(e) => onChangeInput("city",e)}
                                            value={state.city}
                                    /> 
                                    <span className="highlight"></span>
                                    <label>City</label>
                    {errors.city && 
                        <ErrorLabel show text="City is required" color="red" fontSize="20px" />
                    }
                    </div>

                    <div className="floating-label col-3">      
                                    <input className="floating-input" 
                                            
                                            {...register("state" , {required:true})}
                                            name="state"
                                            onChange={(e) => onChangeInput("state",e)}
                                            value={state.state}
                                           
                                    /> 
                                    <span className="highlight"></span>
                                    <label>State</label>
                    {errors.state && 
                        <ErrorLabel show text="State is required" color="red" fontSize="20px" />
                    }
                    </div>

                    <div className="floating-label col-3">      
                                    <input className="floating-input" 

                                            {...register("zip", {required:true})}
                                            name="zip"
                                            onChange={(e) => onChangeInput("zip",e)}
                                            value={state.zip}

                                    /> 
                                    <span className="highlight"></span>
                                    <label>Zip</label>
                    {errors.zip && 
                        <ErrorLabel show text="Zip is required" color="red" fontSize="20px" />
                    }
                    </div>
                    
               </div>
               
               <BottomButtons shouldHideNextButton={shouldHideNextButton}
                                    stepIt={stepIt}
                                    currentStep={currentStep}
                                    submitType
                    />
            </form >

        );
}

export default StepFive;