
import { Steps, Progress, Spin } from 'antd';
const {Step} = Steps;
import React, { useEffect, useState } from 'react';
import * as $ from 'jquery';
import Step1 from './step/step-1';
import Step2 from './step/step-2';
import Step3 from './step/step-3';
import Step4 from './step/step-4';
import Step5 from './step/step-5';
import Step6 from './step/step-6';
import Step7 from './step/step-7';
import logo from '../assets/logo.jpg'
import * as moment from 'moment';
import * as _ from 'underscore';

import { useLocation } from "react-router-dom";
import {getCityAndState} from '../../src/assets/js/axios-calls'
import { clone } from 'underscore';
import BottomButtons from './helper/bottom-buttons';
import { CalendarContainer } from 'react-datepicker';


function VersionOne() {

        const [currentStep, setCurrentStep] = useState(6);
        const [showSpinner, setShowSpinner] = useState(false);
        const [medicareCheckBoxNum, setMedicareCheckBoxNum] = useState(1);
        const [progressPercent, setProgressPercent] = useState(0);
        const [logoContainerStyle, setLogoContainerStyle] = useState({display: 'inline'});
        const search = useLocation().search;
        const zip = new URLSearchParams(search).get('zip');
        const [state, setState] = useState({
                                            Step1_Medicare: '',
                                            Step1_Medicare_Num: 'one',
                                            Gender: 'not specified', 
                                            Month: '1',
                                            Day: '',
                                            Year: '',
                                            firstName: '',
                                            lastName: '',
                                            email: '',
                                            mobile: '',
                                            mobileValid: false,
                                            mobileVerified: false,
                                            drug: 'n',
                                            vision: 'n',
                                            hearing: 'n',
                                            dental: 'y',
                                            street: '',
                                            street2: '',
                                            zip: '',
                                            state: '',
                                            city: '',
                                            consent: 'n',
                                            quoteID: 0
                                          });
        
        
        const getCityAndStateInfo = () => {
            //this.state
            
            let clonedState = _.clone(state);
            clonedState.zip = zip;
            getCityAndState(zip).then(res => {
                if(res.data) {
                    
                    let clonedState = _.clone(state);
                    clonedState.city = res.data.Primary_City;
                    clonedState.state = res.data.State;
                    clonedState.zip = zip;
                    setState(clonedState);
                }
            },err => {
                console.error(err)
            })
            
        }

        const handleResize = function() {
            if(window.innerWidth <= 779) {
                $(".left-steppers").hide();
                $(".top-steppers").show()
                
                setLogoContainerStyle({
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center'
                })

            }
            else {
                $(".left-steppers").show();
                $(".top-steppers").hide();

                setLogoContainerStyle({
                    display: 'inline'
                })
            }
        }

        const isValidDob = () => {
            
            let isValid = state.Year.trim().length == 4 &&
                          (state.Month.trim().length > 0 && state.Month.trim().length < 3) &&
                          (state.Day.trim().length > 0 && state.Day.trim().length < 3)
                          moment(state.Month + "/" + state.Day+ "/" + state.Year).isValid();
            //console.log("isValid", isValid, moment(state.Month + "/" + state.Day+ "/" + state.Year).format('L'));
            return isValid;
        }

        const shouldHideNextButton = () => {
             //(currentStep == 0 && state.Step1_Medicare == '') ||
             return   (currentStep == 1 && ( !isValidDob() || state.Gender == "") ) ||
                      (currentStep == 2 && (state.lastName.trim().length == 0 ||  
                                            state.firstName.trim().length == 0  || 
                                            state.email.trim().length == 0
                                            ) 
                      ) ||
                      (currentStep == 4 && 
                            (state.street.trim().length <= 5 || 
                            state.zip.trim().length != 5 ||
                            state.state.trim().length < 2 ||
                            state.city.trim().length < 2
                            )
                      )
        }

        const stepIt = (stepVal) => {
                setCurrentStep(currentStep + stepVal);
        }

        useEffect(() => {
            $(".main-page").css({
                height: window.innerHeight
            })
           
            getCityAndStateInfo();

            let stateClone = _.clone(state);
            stateClone.quoteID = _.random(1234567890, 9999999999);
            console.log(stateClone.quoteID);
            setTimeout(() => {
                setState(stateClone);   
            },500);
            
            
        },[])
        
        useState(() => {
            console.log("state",state)
        },[state])

        useEffect(() => {
            if(currentStep == 0) {
                setProgressPercent(0);
            }
            else if(currentStep == 1) {
                setProgressPercent(17);
            } else if(currentStep == 2) {
                setProgressPercent(35);
            } else if(currentStep == 3) {
                setProgressPercent(60);
            } else if(currentStep == 4) {
                setProgressPercent(75);
            } else if(currentStep == 5) {
                setProgressPercent(90);
            } else if(currentStep == 6) {
                setProgressPercent(100);
            }
        }, [currentStep])

        return (

            <div className="row">
                <div className="quote-id-container">
                    Quote ID: {state.quoteID}
                </div>
                 {showSpinner && <Spin tip="Please Wait"
                      size="large"
                      style={{position: "absolute", top: "50vh", left: "50vw", zIndex:100}}
    
                />}
                <div className="col-12" style={{display: 'flex', justifyContent: 'center'}}>
                        <img style={{height:"calc(10vh)"}} src={logo} />
                </div>
                {currentStep < 6 && <div className="col-md-1" style={{paddingLeft: "50px", 
                                                  paddingTop: "50px", 
                                                  fontSize: "3rem",
                                                  }}>
                    <Steps className="left-steppers" 
                            direction="vertical" 
                            current={currentStep}>
                        <Step title="1"  />
                        <Step title="2" />
                        <Step title="3" />
                        <Step title="4" />
                        <Step title="5" />
                        <Step title="6" />
                    </Steps>
                    <Progress className="top-steppers" 
                              percent={progressPercent}
                    />
                </div>}

                  <div className="col-md-11">
                    <div className="form-area">
                        {currentStep == 0 && <Step1 currentStep={currentStep} 
                                setCurrentStep={setCurrentStep} 
                                state={state}
                                setState={setState}
                                medicareCheckBoxNum={medicareCheckBoxNum}
                                setMedicareCheckBoxNum={setMedicareCheckBoxNum}
                                stepIt={stepIt}
                        />}

                        {currentStep == 1 && <Step2 currentStep={currentStep} 
                                            setCurrentStep={setCurrentStep} 
                                            state={state}
                                            setState={setState}
                                            isValidDob={isValidDob}
                                            setMedicareCheckBoxNum={setMedicareCheckBoxNum}
                                            stepIt={stepIt}
                                    />}

                        {currentStep == 2 && <Step3 currentStep={currentStep} 
                                                setCurrentStep={setCurrentStep}
                                                state={state}
                                                setState={setState}
                                                setMedicareCheckBoxNum={setMedicareCheckBoxNum}
                                                stepIt={stepIt}
                                        />}

                        {currentStep == 3 && <Step4 currentStep={currentStep} 
                                                setCurrentStep={setCurrentStep}
                                                state={state} 
                                                setState={setState}
                                                setMedicareCheckBoxNum={setMedicareCheckBoxNum}
                                                stepIt={stepIt}
                                        />}

                        {currentStep == 4 && <Step5 currentStep={currentStep} 
                                                setCurrentStep={setCurrentStep}
                                                state={state}
                                                setState={setState}
                                                setMedicareCheckBoxNum={setMedicareCheckBoxNum}
                                                stepIt={stepIt}
                                        />}
                        {currentStep == 5 && <Step6 currentStep={currentStep} 
                                                setCurrentStep={setCurrentStep}
                                                state={state}
                                                setState={setState}
                                                stepIt={stepIt}
                                                setShowSpinner={setShowSpinner}
                                        />}

                        {currentStep == 6 && <Step7 currentStep={currentStep} 
                                                setCurrentStep={setCurrentStep}
                                                state={state}
                                                setState={setState}
                                                stepIt={stepIt}
                                                setShowSpinner={setShowSpinner}
                                                showSpinner={showSpinner}
                                                setShowSpinner={setShowSpinner}
                            />}
                    </div>  
                 </div>
              
                <div style={{position: "fixed", bottom: 0}} className="row actions">
                       
                        
                        {/* <div className="col-md-12">
                            <ul style={{display: "flex",
                                        justifyContent: "center", 
                                        alignItems: "center"}}>
                                {currentStep > 0 && 
                                    <li onClick={() => stepIt(-1)}><span className="js-btn-prev" title="BACK"><i className="fa fa-arrow-left"></i> BACK </span></li>}
                                {currentStep < 5 && !shouldHideNextButton() &&
                                    <li style={{backgroundColor: "#6b59d3"}} 
                                        onClick={() => stepIt(1)}>
                                            <span className="js-btn-next" 
                                                  style={{backgroundColor: "#6b59d3", color: "white"}} 
                                                  title="NEXT">NEXT <i className="fa fa-arrow-right"></i>
                                            </span>
                                    </li>}
                            </ul>
                        </div>         */}
                </div>

               
            </div>
            
            )
    
};


export default VersionOne;

