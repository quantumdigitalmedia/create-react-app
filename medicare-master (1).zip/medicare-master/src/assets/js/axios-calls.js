
import axios from 'axios';
import { notification } from 'antd';

let qdmurl = "https://qdmdev.azurewebsites.net";
//let qdmurl = "http://localhost:49331";

let coreurl = "https://core5.zfcs.us/api"

export const getCityAndState = (zip) => {
   return axios.get(`${qdmurl}/policyfetch/GetCityAndZip?zip=${zip}` );
}

export const sendSms = (num, code) => {
   let number = num;
  
   let text = "Your PolicyFetch mobile verification code is " + code;
   
   return axios.post(`${qdmurl}/twilio/SendMessageWithBody`,
                        {NumberTo: number, Text: text}
                    );
}


export const connectCall = (number, serviceType, message) => {
   // var queryString = "vendor=" + "MedicareVendor"  + "&message=" + "Please wait while we connect you to a medicare expert" + "&number=" + number
   var queryString = "vendor=" + serviceType  + "&message=" + message + "&number=" + number;
   return axios.get(`${qdmurl}/policyfetch/ConnectCall?${queryString}`);
 }

 export const openZoomCall = () => {
   return axios.get(`https://zfcs-node.herokuapp.com/zoom/meetings`);
 }

 export const saveMedicareInfo = (state) => {
   return axios.post(`${qdmurl}/policyfetch/PostMedicare`, state)
 } 


export  const openNotificationWithIcon = (type, title, description) => {
   notification[type]({
     message:title,
     description:description
   });
 };




